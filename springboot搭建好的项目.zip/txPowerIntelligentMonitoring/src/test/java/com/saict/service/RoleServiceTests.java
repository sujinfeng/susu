package com.saict.service;

import com.google.common.collect.Sets;
import com.saict.TxPowerApplication;
import com.saict.entity.Role;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

// 支持数据回滚,避免测试数据污染环境
//@Transactional
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TxPowerApplication.class)
public class RoleServiceTests {


    @Autowired
    private RoleService roleService;
    @Autowired
    private PermissionService permissionService;

    @Test
    public void CRUDTest() {
        Role role = new Role();
        role.setId(1L);
        role.setName("r1");
        roleService.save(role);
        Assert.assertNotNull(role);

        // read
        Role r1 = roleService.get(1L);
        Assert.assertNotNull(r1);

        // update
        System.out.println(r1);
        r1.setName("r3");
        roleService.save(r1);

    }

    @Test
    public void testSaveRoleWithPermission() {
        Role role = new Role();
        role.setId(2L);
        role.setPermissions(Sets.newHashSet(permissionService.findAll()));
        roleService.save(role);

    }


}
