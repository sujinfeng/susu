package com.saict.service;

import com.google.common.collect.Lists;
import com.saict.TxPowerApplication;
import com.saict.entity.Permission;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

// 支持数据回滚,避免测试数据污染环境
//@Transactional
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TxPowerApplication.class)
public class PermissionTests {


    @Autowired
    private PermissionService permissionService;

    @Test
    public void CRUDTest() {
        List<String> ps = Lists.newArrayList();
        ps.add("facility:create");
        ps.add("facility:read");
        ps.add("facility:update");
        ps.add("facility:delete");
        long i = 1L;
        for (String p : ps) {
            Permission permission = new Permission();
            permission.setId(i);
            permission.setName(p);
            System.out.print("permission:::"+permission);
            permissionService.saveAndFlush(permission);
            i++;
        }

    }

}
