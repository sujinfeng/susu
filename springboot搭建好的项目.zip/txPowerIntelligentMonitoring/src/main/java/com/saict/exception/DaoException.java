package com.saict.exception;

/**
 * <p>定义dao(repository)层全局异常 </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:42
 */
@SuppressWarnings("unused")
public class DaoException extends RuntimeException {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 5109234312205055741L;

    public DaoException() {
    }

    public DaoException(String message) {
        super(message);
    }

    public DaoException(Throwable cause) {
        super(cause);
    }

    public DaoException(String message, Throwable cause) {
        super(message, cause);
    }

    public DaoException(String message, Throwable cause,
                        boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
