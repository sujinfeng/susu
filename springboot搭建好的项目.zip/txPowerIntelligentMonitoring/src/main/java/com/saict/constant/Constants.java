package com.saict.constant;

/**
 * <p>
 * 定义系统的一些常量
 * </p>
 *
 * @author : fengx
 * @version 1.0
 * @since : 2019/1/18 11:22
 */
public final class Constants {

    /**
     * shiro采用加密算法
     */
    public static final String HASH_ALGORITHM = "SHA-1";

    /**
     * 生成Hash值的迭代次数
     */
    public static final int HASH_ITERATIONS = 1024;

    /**
     * 生成盐的长度
     */
    public static final int SALT_SIZE = 8;


}
