package com.saict.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.UnsupportedEncodingException;
import java.util.Date;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 10:25
 */
public final class JwtUtil {

    /**
     * 过期时间60分钟
     */
    private static final long EXPIRE_TIME = 60 * 60 * 1000;

    private static final String JSESSIONID = "jsessionid";

    /**
     * 校验token是否正确
     *
     * @param token      密钥
     * @param jsessionid jsessionid
     * @return 是否正确
     */
    public static boolean verify(String token, String username, String jsessionid, String ip) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(jsessionid);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withClaim("username", username)
                    .withClaim("ip", ip)
                    .withClaim(JSESSIONID, jsessionid)
                    .build();
            verifier.verify(token);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }


    /**
     * 获得token中的信息无需secret解密也能获得
     *
     * @param token token
     * @return jsessionid
     */
    public static String getJsessionid(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getClaim(JSESSIONID).asString();
        } catch (JWTDecodeException e) {
            return null;
        }
    }

    /**
     * 生成签名,60min后过期
     *
     * @param username   用户名
     * @param jsessionid jsessionid
     * @return 加密的token
     */
    public static String sign(String username, String jsessionid, String ip) {
        try {
            Date date = new Date(System.currentTimeMillis() + EXPIRE_TIME);
            Algorithm algorithm = Algorithm.HMAC256(jsessionid);
            // 附带username信息
            return JWT.create()
                    .withClaim("username", username)
                    .withClaim("ip", ip)
                    .withClaim(JSESSIONID, jsessionid)
                    .withExpiresAt(date)
                    .sign(algorithm);
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    private JwtUtil() {

    }

}
