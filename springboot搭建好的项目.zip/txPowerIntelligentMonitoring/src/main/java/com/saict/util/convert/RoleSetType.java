package com.saict.util.convert;

import com.saict.entity.Role;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 15:47
 */
public class RoleSetType extends ImmutableSetType<Role> {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    public RoleSetType() {
        super(Role.class);
    }
}
