package com.saict.util.convert;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:54
 */
public class StringListType extends ImmutableListType<String> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public StringListType() {
		super(String.class);
	}
}
