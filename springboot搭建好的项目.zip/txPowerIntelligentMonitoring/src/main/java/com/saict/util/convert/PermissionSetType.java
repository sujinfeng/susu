package com.saict.util.convert;

import com.saict.entity.Permission;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 15:47
 */
public class PermissionSetType extends ImmutableSetType<Permission> {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    public PermissionSetType() {
        super(Permission.class);
    }
}
