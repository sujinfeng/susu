package com.saict.util.http;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;


public final class HttpUtil {

    private HttpUtil() {
    }

    public static boolean isEmpty(String s) {
        return s == null
                || s.length() == 0
                || "null".equals(s)
                || "NaN".equalsIgnoreCase(s);
    }

    /**
     * 取得IP
     *
     * @param request HttpServletRequest
     * @return IP地址
     */
    public static String getRemoteAddr(HttpServletRequest request) {
        // X-Forwarded-For 和 X-Real-IP 的区别？
        String addr = request.getHeader("X-Forwarded-For");
        if (addr == null) {
            addr = request.getHeader(" X-Real-IP");
        }
        if (addr == null) {
            addr = request.getRemoteAddr();
        }
        return addr;
    }

    /**
     * Remove all attributes from Session. WARN: DON'T invoke this function to
     * remove attributes.
     *
     * @param sess HttpSession
     */
    public static void removeAllAttr(HttpSession sess) {
        List<String> keys = new ArrayList<String>();
        Enumeration<String> enu = sess.getAttributeNames();
        while (enu.hasMoreElements()) {
            String nm = enu.nextElement();
            keys.add(nm);
        }
        for (String key : keys) {

            sess.removeAttribute(key);
        }
    }

    public static String getString(HttpServletRequest req, String param) {
        String s = req.getParameter(param);
        return isEmpty(s) ? "" : s;
    }

}
