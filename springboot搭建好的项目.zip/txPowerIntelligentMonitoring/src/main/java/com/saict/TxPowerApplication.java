package com.saict;

import com.saict.util.AppContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * web-app start
 *
 * @author : fengx
 * @version 1.0
 * @since : 2019/1/21 10:00
 */
@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.saict.repository")
@EnableTransactionManagement
@EnableCaching
public class TxPowerApplication {

    public static void main(String[] args) {
        SpringApplication.run(TxPowerApplication.class, args);
    }


    /**
     * 获取Spring容器
     *
     * @return AppContext
     */
    @Bean
    public AppContext appContext() {
        return new AppContext();
    }

}
