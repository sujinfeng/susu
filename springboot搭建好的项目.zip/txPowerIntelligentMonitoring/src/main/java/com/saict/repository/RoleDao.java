package com.saict.repository;

import com.saict.dao.BasicDao;
import com.saict.entity.Role;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:39
 */
public interface RoleDao extends BasicDao<Role, Long> {
}
