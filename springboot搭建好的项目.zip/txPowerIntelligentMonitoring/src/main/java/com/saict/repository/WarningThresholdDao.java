package com.saict.repository;

import com.saict.dao.BasicDao;
import com.saict.entity.WarningThreshold;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:39
 */
public interface WarningThresholdDao extends BasicDao<WarningThreshold, Long> {
}
