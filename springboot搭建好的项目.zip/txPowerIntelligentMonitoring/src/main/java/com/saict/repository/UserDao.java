package com.saict.repository;

import com.saict.dao.BasicDao;
import com.saict.entity.User;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:37
 */
public interface UserDao extends BasicDao<User, Long> {

    /**
     * findByUserName
     *
     * @param userName userName
     * @return User
     */
    User findByUsername(String userName);


}
