package com.saict.filter;

import com.saict.auth.AuthRealm;
import com.saict.util.JwtUtil;
import com.saict.util.http.HttpUtil;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 12:37
 */
public class MyAuthenticationFilter extends BasicHttpAuthenticationFilter {

    private static final String TOKEN = "token";

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        PrincipalCollection principals = SecurityUtils.getSubject().getPrincipals();
        if (principals == null || principals.getPrimaryPrincipal() == null) {
            throw new AuthenticationException();
        }

        String token = WebUtils.toHttp(request).getHeader(TOKEN);

        AuthRealm.ShiroUser shiroUser = (AuthRealm.ShiroUser) principals.getPrimaryPrincipal();
        System.err.println("shiroUSer:" + shiroUser);
        String sessionId = (String) SecurityUtils.getSubject().getSession().getId();
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        System.out.println("jwt:" + JwtUtil.verify(token, shiroUser.getUserName(), sessionId,
                HttpUtil.getRemoteAddr(httpServletRequest)));
        // FIXME 如果这里JWT 校验不成功就直接抛出异常 TODO 校验JWT
        if (!JwtUtil.verify(token, shiroUser.getUserName(), sessionId, HttpUtil.getRemoteAddr(httpServletRequest))) {
            throw new AuthenticationException();
        }
        return super.isAccessAllowed(request, response, mappedValue);
    }
}
