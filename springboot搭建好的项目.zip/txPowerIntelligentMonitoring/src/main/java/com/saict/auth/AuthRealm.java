package com.saict.auth;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Sets;
import com.saict.constant.Constants;
import com.saict.entity.Permission;
import com.saict.entity.Role;
import com.saict.entity.User;
import com.saict.service.UserService;
import com.saict.util.encrypt.Encodes;
import com.saict.util.http.HttpUtil;
import lombok.Data;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.Objects;
import java.util.Set;

/**
 * <p> 自定义realm 用于用户的登录和权限校验</p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:54
 */
@Component(value = "authRealm")
public class AuthRealm extends AuthorizingRealm {

    private UserService userService;

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        ShiroUser shiroUser = (ShiroUser) principals.getPrimaryPrincipal();
        // 给用户授权
        User user = userService.findByUsername(shiroUser.userName);

        Set<String> roles = Sets.newHashSet();
        Set<String> permissions = Sets.newHashSet();
        Set<Permission> permissionSet = Sets.newHashSet();
        for (Role role : user.getRoles()) {
            permissionSet.addAll(role.getPermissions());
            roles.add(role.getName());
        }
        for (Permission permission : permissionSet) {
            permissions.add(permission.getName());
        }
        info.setRoles(roles);
        info.setStringPermissions(permissions);

        return info;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        String username = (String) token.getPrincipal();

        // 查看数据库是否有该用户
        User user = userService.findByUsername(username);
        // 这里判断用户名只是看该用户在数据库中的状态,也可以放在login方法里面去做校验判断
        if (user == null) {
            // 帐号未找到
            throw new UnknownAccountException();
        }
        if (Boolean.TRUE.equals(user.isLocked())) {
            // 帐号锁定
            throw new LockedAccountException();
        }

        byte[] salt = Encodes.decodeHex(user.getSalt());

        ShiroUser shiroUser = new ShiroUser(user.getId(), user.getUsername());
        removeUserAuthorizationInfoCache(shiroUser);
        // 这里去执行校验用户名和密码
        return new SimpleAuthenticationInfo(
                shiroUser,
                // 密码
                user.getPassword(),
                ByteSource.Util.bytes(salt),
                // realm name
                getName()
        );
    }

    /**
     * 清除某个用户已经认证权限的缓存 一般在业务代码中使用
     * key:shiroUser
     */
    private void removeUserAuthorizationInfoCache(ShiroUser user) {
        Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
        cache.remove(user);
    }


    /**
     * 清除所有已经认证权限的缓存
     * key:shiroUser
     */
    public void removeUserAuthorizationInfoCache() {
        Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
        if (cache != null) {
            for (Object key : cache.keys()) {
                cache.remove(key);
            }
        }
    }


    /**
     * 清除所有认证登录权限的缓存
     */
    public void removeUseAuthenticationInfoCache() {
        Cache<Object, AuthenticationInfo> cache = getAuthenticationCache();
        if (cache != null) {
            for (Object key : cache.keys()) {
                cache.remove(key);
            }
        }
    }


    /**
     * 设定Password校验的Hash算法与迭代次数.
     */
    @PostConstruct
    public void initCredentialsMatcher() {
        HashedCredentialsMatcher matcher = new HashedCredentialsMatcher(Constants.HASH_ALGORITHM);
        matcher.setHashIterations(Constants.HASH_ITERATIONS);
        setCredentialsMatcher(matcher);
    }

    @Override
    public String getName() {
        return "myRealm";
    }

    /**
     * 自定义Authentication对象，使得Subject除了携带用户的登录名外还可以携带更多信息.
     */
    @Data
    public static class ShiroUser implements Serializable {


        private static final long serialVersionUID = -1373760761780840081L;

        private Long id;
        private String userName;
        private String ip;

        private ShiroUser(Long id, String userName) {
            this.id = id;
            this.userName = userName;
            HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull
                    (RequestContextHolder.getRequestAttributes())).getRequest();
            this.ip = HttpUtil.getRemoteAddr(request);
        }


        /**
         * 本函数输出将作为默认的"shiro:principal"输出.
         */
        @Override
        public String toString() {
            return JSON.toJSONString(this);
        }


    }

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
}
