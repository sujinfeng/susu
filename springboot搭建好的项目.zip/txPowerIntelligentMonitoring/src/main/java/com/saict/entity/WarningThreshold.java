package com.saict.entity;

import com.saict.serial.IEntity;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <p> 阈值设置 配置实体</p>
 * <p> 严重告警(主要告警)  阈值:8 超阈值次数3 </p>
 * <p> 次要告警           阈值:5 超阈值次数3 </p>
 * <p> 一般告警告警       阈值:2 超阈值次数3 </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:06
 */
@Table
@Entity(name = "bus_warning_threshold")
@Data
public class WarningThreshold implements IEntity {

    @Id
    private String id;

    /**
     * 告警阈值设置
     */
    private double threshold;

    /**
     * 告警次数设置
     */
    private int time;

}
