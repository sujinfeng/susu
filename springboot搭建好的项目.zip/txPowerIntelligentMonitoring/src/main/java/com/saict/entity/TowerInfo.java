package com.saict.entity;

import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.fastjson.JSON;
import lombok.Data;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * <p> 铁塔信息表 </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-16 16:05
 */
@Data
public class TowerInfo extends BaseRowModel {

    @ExcelProperty(index = 0, value = "编号")
    private String number;

    @ExcelProperty(index = 1, value = "名称")
    private String name;

    @ExcelProperty(index = 2, value = "省份")
    private String province;

    @ExcelProperty(index = 3, value = "地市")
    private String city;

    @ExcelProperty(index = 4, value = "县")
    private String county;

    @ExcelProperty(index = 5, value = "乡街道")
    private String street;

    @ExcelProperty(index = 6, value = "经度")
    private double longitude;

    @ExcelProperty(index = 7, value = "纬度")
    private String latitude;

    @ExcelProperty(index = 8, value = "类型")
    private String towerType;

    // 因为日期带有格式,转有问题
//    @ExcelProperty(index = 9, value = "建塔日期", format = "yyyy-MM-dd")
//    private Date createDate;
    @ExcelProperty(index = 9, value = "建塔日期")
    private String createDate;

    @ExcelProperty(index = 10, value = "铁塔高度")
    private int height;

    @ExcelProperty(index = 11, value = "移动天面")
    private String yd;
    @ExcelProperty(index = 12, value = "电信天面")
    private String dx;
    @ExcelProperty(index = 13, value = "联通天面")
    private String lt;


    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

    public static void main(String[] args) throws Exception {


        InputStream inputStream2 = new FileInputStream("/home/dev/fengxiong/project/txPowerIntelligentMonitoring/src/test/java/import.xls");

        InputStream inputStream = new BufferedInputStream(inputStream2);


        // 读取超过1000行使用
        ExcelListener excelListener = new ExcelListener();
        // sheetNo 从1开始计算
        EasyExcelFactory.readBySax(inputStream, new Sheet(2, 1, TowerInfo.class), excelListener);
        for (TowerInfo info : excelListener.getData()) {
            System.err.println(info);
        }


        // 不超过1000行
//        List<Object> data = EasyExcelFactory.read(inputStream, new Sheet(2, 1, TowerInfo.class));
//        for (Object o : data) {
//            System.out.println(o);
//        }

        inputStream.close();
    }


}

class ExcelListener extends AnalysisEventListener<TowerInfo> {


    private List<TowerInfo> data = new ArrayList<>();

    @Override
    public void invoke(TowerInfo object, AnalysisContext context) {
        data.add(object);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
    }

    public List<TowerInfo> getData() {
        return data;
    }
}
