package com.saict.entity;

import com.alibaba.fastjson.JSON;
import com.saict.serial.IEntity;
import lombok.Data;

import javax.persistence.*;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 08:13
 */
@Entity
@Table(name = "sys_permission")
@Data
public class Permission implements IEntity {

    private static final long serialVersionUID = 1L;

    @Id
    private Long id;

    private String name;

    private String resource;

    private String valid;

    private Long lastUpdate;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
