package com.saict.entity;

import com.alibaba.fastjson.JSON;
import com.saict.serial.IEntity;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <p> 设备</p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 08:22
 */
@Table(name = "bus_facility")
@Entity
@Data
public class Facility implements IEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 设备id
     */
    @Id
    private String id;
    /**
     * 设备编号
     */
    private String number;

    private String province;

    private String city;

    /**
     * 县
     */
    private String county;

    /**
     * 乡街道
     */
    private String street;

    /**
     * 经度
     */
    private double longitude;

    /**
     * 纬度
     */
    private String latitude;


    /**
     * 安装情况  installation situation
     */
    private boolean installation;

    /**
     * 激活情况
     */
    private boolean activate;

    /**
     * 状态
     * 1:正常
     * 2:下线
     * 4.XXX
     * 如果只有正常下线两个状态,可以用boolean类型.
     */
    private int status;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }


}
