package com.saict.entity;

import com.saict.serial.IEntity;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 08:31
 */
@Table(name = "bus_warning_detail")
@Entity
@Data
public class WarningDetail implements IEntity {

    @Id
    private String id;
    private String city;
    /**
     * 设备名称
     */
    private String facilityName;
    /**
     * 告警级别
     */
    private String level;
    /**
     * 俯仰角超阈值 pitch angle
     */
    private Double pitchAngle;

    /**
     * 横滚角超阈值 roll angle
     */
    private Double rollAngle;

    /**
     * 处理情况
     * 1:已处理
     * 2:已恢复
     * 4:待处理
     */
    private int deal;

    /**
     * 告警产生时间
     */
    private LocalDateTime creatTime;

}
