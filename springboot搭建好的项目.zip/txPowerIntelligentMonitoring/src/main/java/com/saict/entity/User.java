package com.saict.entity;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Sets;
import com.saict.serial.IEntity;
import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:36
 */
@Entity
@Table(name = "sys_user")
@Data
public class User implements IEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column
    private Long id;

    private String username;

    private String password;

    private String salt;

    private boolean locked;

    private Long lastUpdate;

    private LocalDateTime createTime;


    @Column(name = "roles")
    @Type(type = "com.saict.util.convert.RoleSetType")
    private Set<Role> roles = Sets.newHashSet();

//    @Transient
//    private transient Set<Permission> permissions;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

}
