package com.saict.entity;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Sets;
import com.saict.serial.IEntity;
import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Set;

/**
 * <p>@Proxy(lazy = false) 禁止使用懒加载 </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:36
 */
@Entity
@Table(name = "sys_role")
@Data
public class Role implements IEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column
    private Long id;

    private String name;

    private boolean valid;

    @Column(name = "last_update")
    private Long lastUpdate;

    @Column(name = "permissions")
    @Type(type = "com.saict.util.convert.PermissionSetType")
    private Set<Permission> permissions = Sets.newHashSet();


    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

}
