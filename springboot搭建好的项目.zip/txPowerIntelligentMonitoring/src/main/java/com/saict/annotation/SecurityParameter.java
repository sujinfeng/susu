package com.saict.annotation;

import org.springframework.web.bind.annotation.Mapping;

import java.lang.annotation.*;

/**
 * <p> 定义后台数据加密和解压的注解</p>
 *
 * @author : fengx
 * @version 1.0
 * @since : 2019/2/27 16:47
 */

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Mapping
@Documented
public @interface SecurityParameter {

    /**
     * 入参是否解密，默认解密
     *
     * @return 解密返回true, 否则返回false
     */
    boolean inDecode() default true;

    /**
     * 出参是否加密，默认加密
     *
     * @return 加密返回true, 否则返回false
     */
    boolean outEncode() default true;

}
