package com.saict.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.PropertyFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.IOException;
import java.util.*;


/**
 * <p>
 * 定义后台返回的实体对象
 * </p>
 *
 * @author fengx
 * @version 1.0
 * @since 2019/1/10 10:08
 */
@JsonInclude(Include.NON_NULL)
public final class DSResponse {

    private final static String TOTAL = "total";

    public final static String UTF8 = "UTF-8";

    public final static String DS_DATA = "data";
    /**
     * 返回消息TAG
     */
    public final static String DS_MESSAGE = "message";
    /**
     * SmartClient RestDataSource response TAG
     */
    public final static String DS_RESPONSE = "response";
    /**
     * Response "status" 状态TAG
     */
    public final static String DS_STATUS = "status";
    /**
     * 状态
     */
    private int status = 0;
    /**
     * Response 数据容器
     */
    private Object data;
    /**
     * 消息
     */
    private final List<String> message = new ArrayList<>();
    /**
     * 自定义数据
     */
    private Map<String, Object> extra = new LinkedHashMap<>();

    public static final DSResponse OK = new DSResponse(Status.SUCCESS);
    public static final DSResponse FAILURE = new DSResponse(Status.FAILURE);
    public static final DSResponse SUCCESS = OK;


    public DSResponse() {
    }

    public DSResponse(Object data) {
        this.data = data;
    }

    public DSResponse(int status, String message) {
        this.extra.clear();
        this.data = null;
        this.status = status;
        this.message.clear();
        this.message.add(message);
    }

    public DSResponse(Status status, String message) {
        this(status.id, message == null ? status.val : message);
    }

    public DSResponse(Status status) {
        this(status.id, status.val);
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DSResponse setResponseInfo(int s, String mesg) {
        this.status = s;
        this.setMessage(mesg);
        return this;
    }

    public void setStatus(Status status) {
        this.status = status.id;
        this.message.add(status.val);
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public List<String> getMessage() {
        return message;
    }

    public void setMessage(String mesg) {
        if (mesg == null) {
            mesg = "";
        }
        if (this.message.isEmpty()) {
            this.message.add(mesg);
        } else {
            this.message.set(0, mesg);
        }
    }

    public void setMessage(List<String> message) {
        if (message != null) {
            this.message.addAll(message);
        }
    }

    public void addMessage(String message) {
        this.message.add(message);
    }

    public Map<String, Object> getExtra() {
        return extra;
    }

    public void setExtra(Map<String, Object> extra) {
        if (extra != null) {
            this.extra.putAll(extra);
        }
    }

    public static DSResponse failure(String message) {
        DSResponse response = new DSResponse(Status.FAILURE);
        response.setMessage(message);
        return response;
    }

    public static DSResponse success(String message) {
        DSResponse response = new DSResponse(Status.SUCCESS);
        response.setMessage(message);
        return response;
    }


    public void setParam(String attr, Object value) {
        this.extra.put(attr, value);
    }

    /**
     * 对指字的属性输出JSON串
     *
     * @param inc 包含的属性
     * @param obj 对象
     * @return byte[]
     * @throws IOException IOException
     */
    public static byte[] toJsonStream(Set<String> inc, Object obj) throws IOException {
        PropertyFilter filter = (cls, nm, o) -> {
            return inc.contains(nm);
        };
        String json = JSON.toJSONString(obj, filter);
        return json.getBytes(UTF8);
    }

    public static byte[] toJsonExclude(Set<String> inc, Object obj) throws IOException {
        PropertyFilter filter = (cls, nm, o) -> !inc.contains(nm);
        String json = JSON.toJSONString(obj, filter);
        return json.getBytes(UTF8);
    }

    /**
     * 将统计的结果集放入在extra map中
     *
     * @param extra DsResponse的额外数据集合map
     * @param count 数量统计
     */
    public static void count(Map<String, Object> extra, Object count) {
        extra.put(TOTAL, count);
    }


    public String toJSON() {
        return JSON.toJSONString(this);
//        return JSON.toJSONString(this,
//                SerializerFeature.WriteNullStringAsEmpty,
//                SerializerFeature.WriteMapNullValue);
    }

    @Override
    public String toString() {
        return toJSON();
    }
}
