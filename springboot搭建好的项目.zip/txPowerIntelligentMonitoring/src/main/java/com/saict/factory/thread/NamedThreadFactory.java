package com.saict.factory.thread;

import com.google.common.base.Strings;

import javax.annotation.Nonnull;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * <p>创建线程和线程池时要指定与业务有关的名称，以便在出现问题的时候方便进行定位。
 * 以及使用线程池的情况下，当程序结束时记得调用shutdown来关闭线程池，否则会导致线程池资源一直得不到释放。</p>
 *
 * @author : fengx
 * @version 1.0
 * @since : 2019/7/11 10:12
 */
public class NamedThreadFactory implements ThreadFactory {

    private static final AtomicInteger POOL_NUMBER = new AtomicInteger(1);

    private final ThreadGroup group;

    private final AtomicInteger threadNumber = new AtomicInteger(1);

    private final String namePrefix;

    public NamedThreadFactory(String name) {
        SecurityManager s = System.getSecurityManager();
        group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
        if (Strings.isNullOrEmpty(name)) {
            name = "pool-";
        }
        namePrefix = name + POOL_NUMBER.getAndIncrement() + "-thread-";
    }

    @Override
    public Thread newThread(@Nonnull Runnable r) {

        Thread thread = new Thread(group, r, namePrefix + threadNumber.getAndIncrement(), 0);
        if (thread.isDaemon()) {
            thread.setDaemon(false);
        }
        if (thread.getPriority() != Thread.NORM_PRIORITY) {
            thread.setPriority(Thread.NORM_PRIORITY);
        }
        return thread;
    }
}
