package com.saict.controller;

import com.saict.annotation.SecurityParameter;
import com.saict.entity.User;
import com.saict.factory.thread.NamedThreadFactory;
import com.saict.model.DSResponse;
import com.saict.model.Status;
import com.saict.service.RoleService;
import com.saict.service.UserService;
import com.saict.util.JwtUtil;
import com.saict.util.encrypt.Encodes;
import com.saict.util.http.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.concurrent.Future;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 14:16
 */
@RestController
@RequestMapping("/user")
@Slf4j
@CrossOrigin("*")
public class UserController {

    private UserService userService;

    private RoleService roleService;


    /**
     * http://10.35.16.211:8808/user/save?id=1&username=fengx&password=123456
     *
     * @param user User
     * @return user
     */
    @RequestMapping("/save")
    public User save(User user) {
        Encodes.encryptPassword(user);
        return userService.save(user);
    }

    @RequiresAuthentication
    @RequiresRoles("r1")
    @RequestMapping("/auth")
   // @RequiresPermissions("facility:delete")
    public void auth() {

        System.out.println("auth success");

    }


    @SecurityParameter
    @RequestMapping("/get")
    public User getUser() {
        roleService.get(1L);
        userService.get(1L);
        return userService.findByUsername("fengx");
    }


    @RequestMapping("/login")
    @SecurityParameter(outEncode = false)
    public DSResponse login(HttpServletRequest request, User loginUser) {
        DSResponse response = new DSResponse(Status.SUCCESS);
        String username = loginUser.getUsername();
        String password = loginUser.getPassword();
        Subject subject = SecurityUtils.getSubject();
        // 如果校验该用户已经登录,就不用再次登录校验
        if (subject.isAuthenticated()) {
            response.setData("您已登录!");
            return response;
        }
        UsernamePasswordToken token = new UsernamePasswordToken(username, password, false);
        try {
            subject.login(token);
            log.debug("{} 用户在{}时间登陆系统!", username, LocalDate.now().toString());
            String sessionId = (String) SecurityUtils.getSubject().getSession().getId();
            //  用户第一次登录才签名
            String jwtToken = JwtUtil.sign(username, sessionId, HttpUtil.getRemoteAddr(request));
            response.setData(jwtToken);
        } catch (IncorrectCredentialsException e) {
            response.setStatus(Status.PASSWORD_ERROR);
            return response;
        } catch (UnknownAccountException e) {
            response.setStatus(Status.UN_KNOWN_ACCOUNT);
            return response;
        } catch (LockedAccountException e) {
            response.setStatus(Status.USER_LOCKED);
            return response;
        }
        return response;
    }

    @RequestMapping("/logout")
    public void logout(HttpServletRequest request) {
        final Subject subject = SecurityUtils.getSubject();
        HttpUtil.removeAllAttr(request.getSession());
        try {

            ThreadPoolExecutor executor = new ThreadPoolExecutor(1,
                    1,
                    0, TimeUnit.SECONDS,
                    new SynchronousQueue<>(), new NamedThreadFactory("logout-thread"));

            Future<Integer> future = executor.submit(subject::logout, 0);
            future.get(200, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.warn("user logout error {}", e.getMessage());
        }
    }


    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Autowired
    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }
}
