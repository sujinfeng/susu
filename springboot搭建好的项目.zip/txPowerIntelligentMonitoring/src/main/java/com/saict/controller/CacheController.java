package com.saict.controller;

import com.saict.auth.AuthRealm;
import com.saict.model.DSResponse;
import com.saict.util.AppContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-15 16:37
 */
@RestController
@RequestMapping("/cache")
public class CacheController {


    @RequestMapping("/clear")
    public DSResponse clearUserCache() {
        AuthRealm authRealm = AppContext.getBean(AuthRealm.class);

        authRealm.removeUserAuthorizationInfoCache();
        authRealm.removeUseAuthenticationInfoCache();
        return DSResponse.OK;
    }


}
