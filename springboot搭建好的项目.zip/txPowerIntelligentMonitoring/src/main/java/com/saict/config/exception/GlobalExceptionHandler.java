package com.saict.config.exception;

import com.saict.exception.ServiceException;
import com.saict.model.DSResponse;
import com.saict.model.Status;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 定义全局捕获异常
 *
 * @author : fengx
 * @version 1.0
 * @since : 2019/1/17 15:02
 */
//@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler({UnauthorizedException.class})
    @ResponseBody
    public DSResponse unauthorizedException(HttpServletRequest req, Exception e) {
        return new DSResponse(Status.UNAUTHORIZED_EXCEPTION);
    }

    @ExceptionHandler({UnauthenticatedException.class, AuthorizationException.class})
    @ResponseBody
    public DSResponse defaultExceptionHandler(HttpServletRequest req, Exception e) {
        return new DSResponse(Status.UN_LOGIN_EXCEPTION);
    }

    /**
     * 处理 Exception 异常
     *
     * @param httpServletRequest httpServletRequest
     * @param e                  异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public DSResponse exceptionHandler(HttpServletRequest httpServletRequest, Exception e) {
        log.warn("服务错误:", e);
        DSResponse response = DSResponse.FAILURE;
        response.setMessage("基础Exception出错，请联系后台开发人员");
        return response;
    }

    /**
     * 处理 ServiceException 异常
     *
     * @param httpServletRequest httpServletRequest
     * @param e                  异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = ServiceException.class)
    public DSResponse businessExceptionHandler(HttpServletRequest httpServletRequest, ServiceException e) {
        log.info("业务异常。code:" + e.getMessage() + "msg:" + e.getCode());
        DSResponse response = DSResponse.FAILURE;
        response.setMessage("调用业务服务出错，请联系后台开发人员");
        return response;
    }

}
