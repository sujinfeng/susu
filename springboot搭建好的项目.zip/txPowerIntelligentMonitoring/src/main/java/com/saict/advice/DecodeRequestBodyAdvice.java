package com.saict.advice;

import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.saict.annotation.SecurityParameter;
import com.saict.util.encrypt.AesEncryptUtils;
import com.saict.util.encrypt.RsaUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;

import javax.annotation.Nonnull;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.Objects;

/**
 * 请求数据解密
 *
 * @author fengx
 * @since 2018/10/29 20:17
 */
@ControllerAdvice
@PropertySource("classpath:encrypt/encrypt.properties")
public class DecodeRequestBodyAdvice implements RequestBodyAdvice {

    private static final Logger logger = LoggerFactory.getLogger(DecodeRequestBodyAdvice.class);

    @Value("${server.private.key}")
    private String serverPrivateKey;

    @Override
    public boolean supports(@Nonnull MethodParameter methodParameter, @Nonnull Type type,
                            @Nonnull Class<? extends HttpMessageConverter<?>> aClass) {
        return true;
    }

    @Override
    public Object handleEmptyBody(Object body, @Nonnull HttpInputMessage message,
                                  @Nonnull MethodParameter parameter, @Nonnull Type type,
                                  @Nonnull Class<? extends HttpMessageConverter<?>> aClass) {
        return body;
    }

    @Override
    @Nonnull
    public HttpInputMessage beforeBodyRead(@Nonnull HttpInputMessage inputMessage,
                                           @Nonnull MethodParameter methodParameter,
                                           @Nonnull Type type,
                                           @Nonnull Class<? extends HttpMessageConverter<?>> aClass) {
        try {
            boolean encode = false;
            if (Objects.requireNonNull(methodParameter.getMethod()).isAnnotationPresent(SecurityParameter.class)) {
                // 获取注解配置的包含和去除字段
                SecurityParameter serializedField = methodParameter.getMethodAnnotation(SecurityParameter.class);
                // 入参是否需要解密
                encode = serializedField != null && serializedField.inDecode();
            }
            if (encode) {
                logger.info("对方法method:{}返回数据进行解密",methodParameter.getMethod().getName());
                return new MyHttpInputMessage(inputMessage);
            } else {
                return inputMessage;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("对方法{}返回数据进行解密出现了异常", Objects.requireNonNull(methodParameter.getMethod()).getName(), e);
            return inputMessage;
        }
    }

    @Override
    @Nonnull
    public Object afterBodyRead(@Nonnull Object body, @Nonnull HttpInputMessage message, @Nonnull MethodParameter parameter,
                                @Nonnull Type type, @Nonnull Class<? extends HttpMessageConverter<?>> aClass) {
        return body;
    }

    class MyHttpInputMessage implements HttpInputMessage {
        private HttpHeaders headers;

        private InputStream body;

        private MyHttpInputMessage(HttpInputMessage inputMessage) throws Exception {
            this.headers = inputMessage.getHeaders();
            // 过时  this.body = IOUtils.toInputStream(decryptString(IOUtils.toString(inputMessage.getBody(), "utf-8")));
            String content = decryptString(IOUtils.toString(inputMessage.getBody(), "utf-8"));
            this.body = IOUtils.toInputStream(content, "utf-8");
        }

        @Nonnull
        @Override
        public InputStream getBody() {
            return body;
        }

        @Nonnull
        @Override
        public HttpHeaders getHeaders() {
            return headers;
        }

        /**
         * @param requestData 请求数据string
         * @return String
         */
        private String decryptString(String requestData) {
            if (!Strings.isNullOrEmpty(requestData)) {
                Map<String, String> requestMap = new Gson().fromJson(requestData, new TypeToken<Map<String, String>>() {
                }.getType());
                // 密文
                String data = requestMap.get("requestData");
                // 加密的ase秘钥
                String encrypted = requestMap.get("encrypted");
                if (StringUtils.isEmpty(data) || StringUtils.isEmpty(encrypted)) {
                    throw new RuntimeException("参数【requestData】缺失异常！");
                } else {
                    String content;
                    String aseKey;
                    try {
                        aseKey = RsaUtils.decryptDataOnJava(encrypted, serverPrivateKey);
                    } catch (Exception e) {
                        throw new RuntimeException("参数【aseKey】解析异常！");
                    }
                    try {
                        content = AesEncryptUtils.decrypt(data, aseKey);
                    } catch (Exception e) {
                        throw new RuntimeException("参数【content】解析异常！");
                    }
                    if (StringUtils.isEmpty(content) || StringUtils.isEmpty(aseKey)) {
                        throw new RuntimeException("参数【requestData】解析参数空指针异常!");
                    }
                    return content;
                }
            }
            throw new RuntimeException("参数【requestData】不合法异常！");
        }
    }
}