package com.saict.advice;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.saict.annotation.SecurityParameter;
import com.saict.util.encrypt.AesEncryptUtils;
import com.saict.util.encrypt.RsaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Objects;
import java.util.Random;


/**
 * <p> EncodeResponseBodyAdvic </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-16 16:05
 */
@ControllerAdvice
@PropertySource("classpath:encrypt/encrypt.properties")
public class EncodeResponseBodyAdvice implements ResponseBodyAdvice {

    private final static Logger logger = LoggerFactory.getLogger(EncodeResponseBodyAdvice.class);

    @Value("${client.public.key}")
    private String clientPublicKey;

    /**
     * 随机字符串的长度
     */
    private static final int RANDOM_STRING_LENGTH = 16;

    @Override
    public boolean supports(@Nonnull MethodParameter methodParameter, @Nonnull Class aClass) {
        return true;
    }


    @Override
    public Object beforeBodyWrite(Object body, MethodParameter methodParameter, @Nonnull MediaType mediaType,
                                  @Nonnull Class aClass, @Nonnull ServerHttpRequest serverHttpRequest,
                                  @Nonnull ServerHttpResponse serverHttpResponse) {
        boolean encode = false;
        if (Objects.requireNonNull(methodParameter.getMethod()).isAnnotationPresent(SecurityParameter.class)) {
            // 获取注解配置的包含和去除字段
            SecurityParameter serializedField = methodParameter.getMethodAnnotation(SecurityParameter.class);
            // 出参是否需要加密
            encode = serializedField != null && serializedField.outEncode();
        }
        if (encode) {
            logger.info("对方法method:{}返回数据进行加密", methodParameter.getMethod().getName());
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                String result = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(body);
                // 生成aes秘钥
                String aseKey = getRandomString();
                // rsa加密
                String encrypted = RsaUtils.encryptedDataOnJava(aseKey, clientPublicKey);
                // aes加密
                String requestData = AesEncryptUtils.encrypt(result, aseKey);
                Map<String, String> map = Maps.newHashMap();
                map.put("encrypted", encrypted);
                map.put("requestData", requestData);
                return map;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return body;
    }

    /**
     * 创建指定位数的随机字符串
     *
     * @return 字符串
     */
    private static String getRandomString() {
        String base = "eZkz6ivcBZGeYa8If0V58ZhTkiZ3Q6TJNWZzODbpebX5KP7ccju9zuUyrUB7LZhY";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

}