package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.WarningDetail;
import com.saict.repository.WarningDetailDao;
import com.saict.service.BaseService;
import com.saict.service.WarningDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:24
 */
@Service
public class WarningDetailServiceImpl extends BaseService<WarningDetail, String> implements WarningDetailService {

    private WarningDetailDao dao;

    @Override
    public BasicDao<WarningDetail, String> getDao() {
        return dao;
    }

    @Autowired
    public void setDao(WarningDetailDao dao) {
        this.dao = dao;
    }
}
