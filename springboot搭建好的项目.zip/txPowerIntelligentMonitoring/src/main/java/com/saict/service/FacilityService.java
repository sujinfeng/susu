package com.saict.service;

import com.saict.entity.Facility;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:28
 */
public interface FacilityService extends IService<Facility, String> {
}
