package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.Facility;
import com.saict.repository.FacilityDao;
import com.saict.service.BaseService;
import com.saict.service.FacilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:28
 */
@Service
public class FacilityServiceImpl extends BaseService<Facility, String> implements FacilityService {

    private FacilityDao dao;

    @Override
    public BasicDao<Facility, String> getDao() {
        return dao;
    }

    @Autowired
    public void setDao(FacilityDao dao) {
        this.dao = dao;
    }
}
