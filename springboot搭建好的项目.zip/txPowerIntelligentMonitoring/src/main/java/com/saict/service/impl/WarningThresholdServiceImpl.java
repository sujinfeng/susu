package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.WarningThreshold;
import com.saict.repository.WarningThresholdDao;
import com.saict.service.BaseService;
import com.saict.service.WarningThresholdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:26
 */
@Service
public class WarningThresholdServiceImpl extends BaseService<WarningThreshold, Long> implements WarningThresholdService {


    private WarningThresholdDao dao;

    @Override
    public BasicDao<WarningThreshold, Long> getDao() {
        return dao;
    }

    @Autowired
    public void setDao(WarningThresholdDao dao) {
        this.dao = dao;
    }
}
