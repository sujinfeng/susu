package com.saict.service;

import com.saict.entity.Role;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:39
 */
public interface RoleService extends IService<Role, Long> {
}
