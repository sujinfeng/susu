package com.saict.service;

import com.saict.dao.BasicDao;
import com.saict.serial.IEntity;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;

import java.io.Serializable;
import java.util.List;

/**
 * <p> implements some dao function </p>
 * <p>include CRUD function </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:10
 */
public abstract class BaseService<T extends IEntity, ID extends Serializable>
        implements IService<T, ID> {


    /**
     * implements service  get dao
     *
     * @return BasicDao
     */
    public abstract BasicDao<T, ID> getDao();


    @Override
    public List<T> findAll() {
        return getDao().findAll();
    }

    @Override
    public List<T> findAll(Sort var1) {
        return getDao().findAll(var1);
    }

    @Override
    public List<T> findAllById(Iterable<ID> var1) {
        return getDao().findAllById(var1);
    }

    @Override
    public <S extends T> List<S> saveAll(Iterable<S> var1) {
        return getDao().saveAll(var1);
    }

    @Override
    public void flush() {
        getDao().flush();
    }

    @Override
    public <S extends T> S saveAndFlush(S var1) {
        return getDao().saveAndFlush(var1);
    }

    @Override
    public <S extends T> S save(S var1) {
        return getDao().save(var1);
    }

    @Override
    public void deleteInBatch(Iterable<T> var1) {
        getDao().deleteInBatch(var1);
    }

    @Override
    public void deleteAllInBatch() {
        throw new UnsupportedOperationException("can'not delete all db record");
    }

    @Override
    public T get(ID var1) {
        // getOne(var) could occur lazy load Exception, so we could use findById.
        return getDao().findById(var1).orElse(null);
    }

    @Override
    public <S extends T> List<S> findAll(Example<S> var1) {
        return getDao().findAll(var1);
    }

    @Override
    public <S extends T> List<S> findAll(Example<S> var1, Sort var2) {
        return getDao().findAll(var1, var2);
    }
}
