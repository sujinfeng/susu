package com.saict.service;

import com.saict.entity.Permission;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:18
 */
public interface PermissionService extends IService<Permission, Long> {
}
