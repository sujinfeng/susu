package com.saict.service;

import com.saict.entity.User;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:39
 */
public interface UserService extends IService<User, Long> {

    /**
     * find User by userName
     *
     * @param userName userName
     * @return User
     */
    User findByUsername(String userName);


}
