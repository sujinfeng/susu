package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.Permission;
import com.saict.repository.PermissionDao;
import com.saict.service.BaseService;
import com.saict.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p> </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:18
 */
@Service
public class PermissionServiceImpl extends BaseService<Permission, Long> implements PermissionService {

    private PermissionDao dao;

    @Override
    public BasicDao<Permission, Long> getDao() {
        return dao;
    }

    @Autowired
    public void setDao(PermissionDao dao) {
        this.dao = dao;
    }
}
