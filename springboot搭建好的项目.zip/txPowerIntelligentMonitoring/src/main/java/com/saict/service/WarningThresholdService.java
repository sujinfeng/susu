package com.saict.service;

import com.saict.entity.WarningThreshold;

/**
 * @author fengx
 * @version 1.0
 * @since 19-7-12 09:25
 */
public interface WarningThresholdService extends IService<WarningThreshold, Long> {
}
