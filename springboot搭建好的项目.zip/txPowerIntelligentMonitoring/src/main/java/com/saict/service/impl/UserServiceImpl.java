package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.User;
import com.saict.repository.UserDao;
import com.saict.service.BaseService;
import com.saict.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * <p> UserServiceImpl </p>
 * FIX ME BUG:USER CACHE VALID 用户缓存不生效
 * 当项目启动后重新编译下该class类.缓存注解生效.
 * 初步猜测是因为AuthRealm的依赖导致这个bug产生的
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:40
 */
@Service
public class UserServiceImpl extends BaseService<User, Long> implements UserService {


    private UserDao userDao;



    @Override
    public BasicDao<User, Long> getDao() {
        return userDao;
    }

    @Override
    @Cacheable(value = "user", keyGenerator = "keyGenerator")
    public User findByUsername(String userName) {
        return userDao.findByUsername(userName);
    }

    @Override
    @Cacheable(value = "user", keyGenerator = "keyGenerator")
    public User get(Long id) {
        return userDao.findById(id).orElse(null);

    }

    @Autowired
    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }


}
