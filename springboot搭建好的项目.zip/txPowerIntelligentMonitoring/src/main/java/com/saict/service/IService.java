package com.saict.service;

import com.saict.serial.IEntity;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;

import java.io.Serializable;
import java.util.List;

/**
 * <p>basic service interface </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:07
 */
@SuppressWarnings("unused")
public interface IService<T extends IEntity, ID extends Serializable> {

    /**
     * findAll
     *
     * @return entity collection
     */
    List<T> findAll();

    /**
     * findAll by Sort
     *
     * @param var1 Sort
     * @return entity collection
     */
    List<T> findAll(Sort var1);

    /**
     * findAll by Ids
     *
     * @param var1 id collections
     * @return entity collection
     */
    List<T> findAllById(Iterable<ID> var1);

    /**
     * save entity collection
     *
     * @param var1 entity collection
     * @param <S>  entityClass
     * @return entity collection
     */
    <S extends T> List<S> saveAll(Iterable<S> var1);

    /**
     * dao flush
     */
    void flush();

    /**
     * save entity and flush to db
     *
     * @param var1 entity
     * @param <S>  entityClass
     * @return a entity
     */
    <S extends T> S saveAndFlush(S var1);

    /**
     * save entity
     *
     * @param var1 entity
     * @param <S>  entityClass
     * @return a entity
     */
    <S extends T> S save(S var1);

    /**
     * delete by ids Collections
     *
     * @param var1 entity id collection
     */
    void deleteInBatch(Iterable<T> var1);

    /**
     * delete all db'srecord
     */
    void deleteAllInBatch();

    /**
     * get entity by id
     *
     * @param var1 id
     * @return a entity
     */
    T get(ID var1);

    /**
     * findAll by Example
     *
     * @param var1 Example
     * @param <S>  entityClass
     * @return entity Collection
     */
    <S extends T> List<S> findAll(Example<S> var1);

    /**
     * findAll by Example and Sort
     *
     * @param var1 Example
     * @param var2 Sort
     * @param <S>  entityClass
     * @return entity collection
     */
    <S extends T> List<S> findAll(Example<S> var1, Sort var2);
}
