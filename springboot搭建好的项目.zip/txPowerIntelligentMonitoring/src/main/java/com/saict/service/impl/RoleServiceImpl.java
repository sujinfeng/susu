package com.saict.service.impl;

import com.saict.dao.BasicDao;
import com.saict.entity.Role;
import com.saict.repository.RoleDao;
import com.saict.service.BaseService;
import com.saict.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * <p> RoleServiceImpl </p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 13:46
 */
@Service
public class RoleServiceImpl extends BaseService<Role, Long> implements RoleService {

    private RoleDao roleDao;

    @Override
    public BasicDao<Role, Long> getDao() {
        return roleDao;
    }

    @Autowired
    public void setRoleDao(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    @Cacheable(value = "role_get", keyGenerator = "keyGenerator")
    public Role get(Long id) {
        return roleDao.findById(id).orElse(null);
    }

}
