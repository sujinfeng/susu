package com.saict.serial;


import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * <p>数据库对应的实体接口</p>
 * <p>
 * 要求所有数据库实体继承。
 * </p>
 *
 * @author fengx
 * @version 1.0
 * @since 2019/1/10 10:08
 */
public interface IEntity extends Serializable, Cloneable {

    /**
     * 默认函数 name()，根据注解，取得数据库表的本地名。
     *
     * @return 表名
     */
    default String name() {
        Table tb = getClass().getAnnotation(Table.class);
        String tbName = (tb == null) ? null : tb.name();
        if (tbName != null) {
            return tbName;
        }
        // 在entity查看注解 name=""
        Entity e = getClass().getAnnotation(Entity.class);
        return (e == null) ? null : e.name();
    }

}
