package com.saict.dao;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p> extends JpaRepository </p>
 * <p> convenient extension</p>
 *
 * @author fengx
 * @version 1.0
 * @since 19-7-11 12:11
 */
public interface BasicDao<T, ID> extends JpaRepository<T, ID> {
}
